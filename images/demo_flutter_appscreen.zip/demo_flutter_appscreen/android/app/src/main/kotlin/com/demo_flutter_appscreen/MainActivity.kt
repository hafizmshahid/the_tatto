package com.demo_flutter_appscreen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
