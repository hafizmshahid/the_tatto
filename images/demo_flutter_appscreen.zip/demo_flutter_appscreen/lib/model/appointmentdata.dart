import 'package:demo_flutter_appscreen/separator/separator.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class AppointmentData extends StatelessWidget {
  final String discount;
  final Color dark_color;
  final Color light_color;

  const AppointmentData({Key key, this.discount, this.dark_color, this.light_color})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Container(
      color: Colors.white,


      child: Container(
          margin: EdgeInsets.only(left: 10, right: 10, top: 10),
          height: 190,
          // constraints: BoxConstraints.expand(),
          width: double.infinity,
          decoration: BoxDecoration(
            border: Border.all(color: const Color(0xFFf1f1f1), width: 2),
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),


          child: ListView(
            physics: NeverScrollableScrollPhysics(),
            // mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              Expanded(
                  child: Container(
                      alignment: Alignment.topLeft,
                      margin: EdgeInsets.only(left: 5.0, top: 0.0),
                      child: Row(
                        children: <Widget>[

                          Expanded(
                            child:  new Container(
                              height: 75,
                              width: 75.0,
                              // color: Colors.black,
                              alignment: Alignment.topLeft,


                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10.0),
                                image: DecorationImage(
                                  image: AssetImage(
                                      "images/the_barber.jpg"),
                                  fit: BoxFit.fitWidth,
                                  alignment: Alignment.topCenter,
                                ),
                              ),


                            ),
                          ),



                          new Container(
                            // height: 100.0,
                              width: MediaQuery
                                  .of(context)
                                  .size
                                  .width * 0.65,
                              height: 110,
                              margin: EdgeInsets.only(left: 5.0, top: 0.0),
                              alignment: Alignment.topLeft,
                              color: Colors.white,


                              child: ListView(
                                physics: NeverScrollableScrollPhysics(),

                                children: <Widget>[

                                  Expanded(child:

                                  Container(

                                    margin: EdgeInsets.only(top: 25.0),

                                    child: Text("Barberque", style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600,
                                        fontFamily: 'Montserrat'

                                    ),),
                                  ),


                                  ),
                                  Expanded(

                                    child: Container(

                                      margin: EdgeInsets.only(top: 5.0,left: 0.0),

                                      child: Text("vishwashanti marg, near lnn, pune ",
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                        style: TextStyle(
                                            color: Colors.grey,
                                            fontSize: 11,
                                            fontWeight: FontWeight.w700,
                                            fontFamily: 'Montserrat'

                                        ),),
                                    ),

                                  ),

                                  Expanded(
                                    child: Row(

                                      children: <Widget>[

                                        Container(
                                            margin: EdgeInsets.only(left: 0.0,top: 5.0),
                                            child: RichText(
                                              text: TextSpan(
                                                children: [

                                                  WidgetSpan(
                                                    child: Icon(Icons.star, size: 14,
                                                      color: Colors.yellow,),
                                                  ),
                                                  TextSpan(
                                                      text: "4.0 ",
                                                      style: TextStyle(color: Colors.grey,
                                                          fontSize: 11,
                                                          fontWeight: FontWeight.w600)
                                                  ),
                                                  TextSpan(
                                                      text: "Rating",
                                                      style: TextStyle(color: Colors.grey,
                                                          fontSize: 11,
                                                          fontWeight: FontWeight.w600)
                                                  ),


                                                ],
                                              ),
                                            )


                                        ),

                                        Container(
                                          alignment: Alignment.center,

                                          width: 5.0,
                                          height: 5.0,
                                          margin: EdgeInsets.only(left: 5.0,top: 5.0),
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: Colors.grey,
                                          ),
                                        ),

                                        Container(
                                            margin: EdgeInsets.only(left: 0.0,top: 5.0,right: 0),
                                            child: RichText(
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                              textScaleFactor: 1,
                                              textAlign: TextAlign.center,

                                              text: TextSpan(
                                                children: [

                                                  WidgetSpan(

                                                    child: Icon(Icons.calendar_today, size: 14,
                                                      color: const Color(0xFFe06287),),
                                                  ),
                                                  TextSpan(

                                                      text: "06:00 pm - June 21,2020",


                                                      style: TextStyle(color: Colors.grey,
                                                          fontSize:11,
                                                          fontWeight: FontWeight.w600)
                                                  ),



                                                ],
                                              ),
                                            )


                                        )


                                      ],

                                    ),


                                  ),

                                ],

                              )

                          ),


                        ],
                      )
                  )
              ),

              Expanded(child: Container(


                child:Container(
                  margin: const EdgeInsets.only(top: 1.0,bottom:1.0),
                  padding: const EdgeInsets.only(left: 10.0,right: 10.0),
                  child:
                  MySeparator(color: Colors.grey),
                ),


              )
              ),
              Expanded(
                  child: Container(
                      alignment: Alignment.topLeft,
                      margin:
                      EdgeInsets.only(left: 10.0, top: 15.0, bottom: 10.0),
                      child: Row(
                        children: <Widget>[

                          new Column(

                            children: <Widget>[
                              new Container(

                                //width: 75.0,
                                alignment: Alignment.topLeft,
                                transform: Matrix4.translationValues(-5.0, -20.0, 0.0),
                                child: Text('Service Type:',style: TextStyle(color:Colors.grey,fontFamily: 'Montserrat',fontWeight: FontWeight.w600,fontSize: 11),),

                              ),
                              new Container(

                                //width: 75.0,
                                alignment: Alignment.topLeft,
                                transform: Matrix4.translationValues(5.0, -18.0, 0.0),
                                child: Text('Multipal HairStyle',style: TextStyle(color:Colors.black,fontFamily: 'Montserrat',fontWeight: FontWeight.w600,fontSize: 11),),

                              ),

                              new Container(

                                //width: 75.0,
                                alignment: Alignment.topLeft,
                                transform: Matrix4.translationValues(-20.0, -10.0, 0.0),
                                child: Text('see all...',style: TextStyle(color:Colors.blueAccent,fontFamily: 'Montserrat',fontWeight: FontWeight.w600,fontSize: 11),),

                              ),




                            ],

                          ),


                          new Container(
                            // height: 100.0,
                            width: MediaQuery.of(context).size.width * 0.5,
                            height: 90,
                            transform: Matrix4.translationValues(5.0, -20.0, 0.0),
                            // margin: EdgeInsets.only(
                            //     left: 15.0, top: 1.0, bottom: 10.0),
                            alignment: Alignment.centerRight,
                            // decoration: BoxDecoration(
                            //     color: Colors.white,
                            //     borderRadius:
                            //         BorderRadius.all(Radius.circular(1))),


                            child:GestureDetector(
                                onTap: (){

                                  showcancledialog(context);


                                },

                                child: RichText(
                                  text: TextSpan(
                                    children: [

                                      WidgetSpan(
                                        child: Icon(Icons.delete, size: 14,
                                          color: const Color(0xFFff4040),),
                                      ),
                                      TextSpan(
                                          text: "Cancel Booking",
                                          style: TextStyle(color: const Color(0xFFff4040),
                                              fontSize: 11,
                                              fontWeight: FontWeight.w500)
                                      ),



                                    ],
                                  ),
                                )

                            ),



                          ),
                        ],
                      ))),
            ],
          ),


          // color: Colors.grey,


        ),
    );

  }

  void showcancledialog(BuildContext context) {

    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {

          Widget cancelButton = FlatButton(
            child: Text("No",style: TextStyle(color: Colors.grey,fontSize: 16,fontWeight: FontWeight.w600,fontFamily: 'Montserrat'),),
            onPressed:  () {
              Navigator.pop(context);


            },
          );
          Widget continueButton = FlatButton(
            child: Text("Yes",style: TextStyle(color: const Color(0xFFe06287),fontSize: 16,fontWeight: FontWeight.w600,fontFamily: 'Montserrat'),),
            onPressed:  () {
              Navigator.pop(context);

            },
          );

          return AlertDialog(
            actions: [
              cancelButton,
              continueButton,
            ],


            title: Center(child: Text('Cancel Appointment !',style: TextStyle(color: Colors.black,fontSize: 20,fontWeight: FontWeight.w600,fontFamily: 'Montserrat'),)),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  child: Text(
                    "Are you sure you want to cancel your appointment?  ",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Colors.grey,fontWeight: FontWeight.w800,fontSize: 18,fontFamily: 'Montserrat'
                    ),
                  ),
                ),

              ],
            ),
          );
        });




  }


}


