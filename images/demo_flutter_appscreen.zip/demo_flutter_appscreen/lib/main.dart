import 'dart:async';
import 'package:demo_flutter_appscreen/screens/loginscreen.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(new MaterialApp(

    debugShowCheckedModeBanner: false,
    home: new SplashScreen(),
    routes: <String, WidgetBuilder>{
      '/HomeScreen': (BuildContext context) => new LoginScreen()
    },
  ));
}

class SplashScreen extends StatefulWidget {

  @override
  _SplashScreenState createState() => new _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  startTime() async {
    var _duration = new Duration(seconds: 5);
    return new Timer(_duration, navigationPage);
  }




  void navigationPage() {
    Navigator.of(context).pushReplacementNamed('/HomeScreen');
  }

  @override
  void initState() {
    super.initState();
   startTime();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(



      body: new Container(
          decoration: BoxDecoration(
            color: const Color(0xff7c94b6),
            image: DecorationImage(image: AssetImage("images/the_barber.jpg"), fit: BoxFit.cover,
                colorFilter: new ColorFilter.mode(Colors.black.withOpacity(0.2), BlendMode.dstATop) ),

          ),



        child: Stack(
          children: <Widget>[

            Expanded(

                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Expanded(
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 45.0,left: 70.0),
                        alignment: FractionalOffset.bottomLeft,

                        child: Text("The",
                          textAlign: TextAlign.end,
                          style: TextStyle(color: Colors.white,fontSize: 30,fontWeight: FontWeight.w500,fontFamily: 'Montserrat'),
                        ),
                      ),
                    ),
                  ],
                )

            ),

            Expanded(
                child: Container(
                  margin: const EdgeInsets.only(top: 1.0,left: 110.0),


                  alignment: FractionalOffset.bottomLeft,
                  child: Text("BARBER.",
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white,fontSize: 50,fontWeight: FontWeight.w700,fontFamily: 'Montserrat'),
                  ), )
            )





          ],


        )


      /*

        ),*/



      ),
    );
  }
}