import 'dart:async';
import 'package:demo_flutter_appscreen/screens/forgotpassword.dart';
import 'package:demo_flutter_appscreen/screens/homescreen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'loginscreen.dart';

void main() {
  runApp(new MaterialApp(
    debugShowCheckedModeBanner: false,
    home: new RegisterScreen(),



  ));
}


class RegisterScreen extends StatefulWidget {
  @override
  _RegisterScreen createState() => new _RegisterScreen();



}

class _RegisterScreen extends State<RegisterScreen> {
  String _selectedCountryCode = '+91';
  List<String> _countryCodes = ['+91', '+23','+8'];
  FocusNode myFocusNode;





  @override
  Widget build(BuildContext context) {
    var countryDropDown = Container(
      decoration: new BoxDecoration(
        color: const Color(0xFFf1f1f1),
        border: Border(
          right: BorderSide(width: 0.5, color: const Color(0xFFf1f1f1)),
        ),
      ),
      // height: 45.0,

     // margin: const EdgeInsets.all(3.0),
      //width: 300.0,
      child: DropdownButtonHideUnderline(
        child: ButtonTheme(
          alignedDropdown: false,
          child: DropdownButton(

            // iconSize: 0.0,

            value: _selectedCountryCode,
            items: _countryCodes.map((String value) {

              return new DropdownMenuItem<String>(
                  value: value,
                  child: new Text(


                    value,
                    style: TextStyle(fontSize: 12.0),
                  ));
            }).toList(),
            onChanged: (value) {
              setState(() {

                _selectedCountryCode = value;
              });
            },
            style: Theme.of(context).textTheme.title,
          ),
        ),
      ),
    );
   //  return new Scaffold(
   //    resizeToAvoidBottomPadding : false,
   //
   //    backgroundColor: Colors.white,
   //
   //
   //
   //
   //
   // body: Container(
   //
   //   child: Column(
   //
   //     children: <Widget>[
   //
   //       Expanded(
   //         child: ListView(
   //     children: [
   //
   //        Row(
   //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
   //
   //         children: <Widget>[
   //
   //           Flexible(
   //             child: Container(
   //                 margin: const EdgeInsets.only(top: 20.0, left: 2.0),
   //                 alignment: FractionalOffset.topLeft,
   //                 child: IconButton(
   //                     icon: Icon(Icons.keyboard_arrow_left),
   //                     color: Colors.black,
   //                     iconSize: 30,
   //                     onPressed: () => Navigator.of(context).pop())),
   //           ),
   //
   //           Flexible(
   //             child: Container(
   //               margin: const EdgeInsets.only(top: 30.0, left: 2.0),
   //               transform: Matrix4.translationValues(-100.0, 0.0, 0.0),
   //               alignment: FractionalOffset.topCenter,
   //               child: Text(
   //                 "Create New Account",
   //                 textAlign: TextAlign.center,
   //                 style: TextStyle(
   //                     color: Colors.black,
   //                     fontSize: 18,
   //                     fontWeight: FontWeight.w600,
   //                     fontFamily: 'Montserrat'),
   //               ),
   //             ),
   //           ),
   //
   //
   //         ],
   //       ),
   //
   //
   //
   //
   //
   //
   //
   //
   //
   //             Container(
   //               child:Container(
   //                 margin: const EdgeInsets.only(top: 100.0, left:22.0),
   //                 alignment: FractionalOffset.topLeft,
   //                 child: Text("Name",textAlign: TextAlign.center,
   //                   style: TextStyle(
   //                       color: const  Color(0xFF999999),
   //                       fontSize: 16,
   //                       fontWeight: FontWeight.w600,
   //                       fontFamily: 'Montserrat'),),
   //               ),
   //
   //
   //
   //
   //
   //             ),
   //
   //
   //             Container(
   //               alignment: FractionalOffset.topLeft,
   //
   //               margin: const EdgeInsets.only(
   //                   top: 5.0, left: 20.0, right: 20.0),
   //               child: TextField(
   //                 autofocus: true,
   //                 keyboardType: TextInputType.name,
   //
   //                 textInputAction: TextInputAction.next,
   //                 onSubmitted: (_) => FocusScope.of(context).nextFocus(),
   //                 style: TextStyle(fontSize: 18.0, color: Colors.black),
   //                 decoration: InputDecoration(
   //                   filled: true,
   //                   fillColor: const Color(0xFFf1f1f1),
   //                   hintText: 'Enter your full name',
   //                   contentPadding: const EdgeInsets.only(
   //                       left: 14.0, bottom: 8.0, top: 8.0),
   //                   focusedBorder: OutlineInputBorder(
   //                     borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
   //                     borderRadius: BorderRadius.circular(5),
   //                   ),
   //                   enabledBorder: UnderlineInputBorder(
   //                     borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
   //                     borderRadius: BorderRadius.circular(5),
   //                   ),
   //                 ),
   //               ),
   //             ),
   //             Container(
   //               margin: const EdgeInsets.only(top: 5.0, left:22.0),
   //               alignment: FractionalOffset.topLeft,
   //               child: Text("Email id",textAlign: TextAlign.center,
   //                 style: TextStyle(
   //                     color: const  Color(0xFF999999),
   //                     fontSize: 16,
   //                     fontWeight: FontWeight.w600,
   //                     fontFamily: 'Montserrat'),),
   //             ),
   //
   //             Container(
   //               alignment: FractionalOffset.topLeft,
   //
   //               margin: const EdgeInsets.only(
   //                   top: 5.0, left: 20.0, right: 20.0),
   //               child: TextField(
   //                 autofocus: true,
   //                 keyboardType: TextInputType.emailAddress,
   //                 focusNode: myFocusNode,textInputAction: TextInputAction.next,
   //                 onSubmitted: (_) => FocusScope.of(context).nextFocus(),
   //                 style: TextStyle(fontSize: 18.0, color: Colors.black),
   //                 decoration: InputDecoration(
   //                   filled: true,
   //                   fillColor: const Color(0xFFf1f1f1),
   //                   hintText: 'Enter your email id',
   //                   contentPadding: const EdgeInsets.only(
   //                       left: 14.0, bottom: 8.0, top: 8.0),
   //                   focusedBorder: OutlineInputBorder(
   //                     borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
   //                     borderRadius: BorderRadius.circular(5),
   //                   ),
   //                   enabledBorder: UnderlineInputBorder(
   //                     borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
   //                     borderRadius: BorderRadius.circular(5),
   //                   ),
   //                 ),
   //               ),
   //             ),
   //             Container(
   //               margin: const EdgeInsets.only(top: 5.0, left:22.0),
   //               alignment: FractionalOffset.centerLeft,
   //               child: Text("Phone Number",textAlign: TextAlign.center,
   //                 style: TextStyle(
   //                     color: const  Color(0xFF999999),
   //                     fontSize: 16,
   //                     fontWeight: FontWeight.w600,
   //                     fontFamily: 'Montserrat'),),
   //             ),
   //
   //
   //             Container(
   //                 alignment: FractionalOffset.centerLeft,
   //
   //                 margin: const EdgeInsets.only(
   //                     top: 5.0, left: 20.0, right: 20.0),
   //
   //                 child:Align(
   //                   alignment: Alignment.centerLeft,
   //
   //                   child: TextField(
   //
   //
   //                     autofocus: true,
   //                     textAlign: TextAlign.left,
   //                     keyboardType: TextInputType.number,
   //                     textInputAction: TextInputAction.next,
   //                     onSubmitted: (_) => FocusScope.of(context).nextFocus(),
   //                     style: TextStyle(fontSize: 18.0, color: Colors.black,),
   //                     decoration: InputDecoration(
   //                       prefixIcon: countryDropDown ,
   //                       filled: true,
   //                       fillColor: const Color(0xFFf1f1f1),
   //                       hintText: 'Phone Number ',
   //                       contentPadding: const EdgeInsets.only(
   //                           left: 14.0, bottom: 8.0, top: 8.0),
   //                       focusedBorder: OutlineInputBorder(
   //                         borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
   //                         borderRadius: BorderRadius.circular(5),
   //                       ),
   //                       enabledBorder: UnderlineInputBorder(
   //                         borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
   //                         borderRadius: BorderRadius.circular(5),
   //                       ),
   //                     ),
   //                   ),
   //
   //
   //                 )
   //
   //             ),
   //             Container(
   //               margin: const EdgeInsets.only(top: 5.0, left:22.0),
   //               alignment: FractionalOffset.centerLeft,
   //               child: Text("PassWord",textAlign: TextAlign.center,
   //                 style: TextStyle(
   //                     color: const  Color(0xFF999999),
   //                     fontSize: 16,
   //                     fontWeight: FontWeight.w600,
   //                     fontFamily: 'Montserrat'),),
   //             ),
   //
   //             Container(
   //               alignment: FractionalOffset.centerLeft,
   //
   //               margin: const EdgeInsets.only(
   //                   top: 5.0, left: 20.0, right: 20.0),
   //               child: TextField(
   //
   //                 autofocus: true,
   //                 obscureText:true,
   //                 textInputAction: TextInputAction.next,
   //                 onSubmitted: (_) => FocusScope.of(context).nextFocus(),
   //                 style: TextStyle(fontSize: 18.0, color: Colors.black),
   //                 decoration: InputDecoration(
   //                   filled: true,
   //                   fillColor: const Color(0xFFf1f1f1),
   //                   hintText: 'Enter your Password',
   //                   contentPadding: const EdgeInsets.only(
   //                       left: 14.0, bottom: 8.0, top: 8.0),
   //                   focusedBorder: OutlineInputBorder(
   //                     borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
   //                     borderRadius: BorderRadius.circular(5),
   //                   ),
   //                   enabledBorder: UnderlineInputBorder(
   //                     borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
   //                     borderRadius: BorderRadius.circular(5),
   //                   ),
   //                 ),
   //               ),
   //             ),
   //             Container(
   //
   //                 margin: const EdgeInsets.only(top: 20.0),
   //                 alignment: FractionalOffset.center,
   //                 // width: 500,
   //                 // height: 50,
   //                 // color: Colors.pink,
   //
   //                 child: MaterialButton(
   //                   shape: new RoundedRectangleBorder(borderRadius: new BorderRadius.circular(5.0))
   //  ,
   //                   minWidth: 300,
   //                   height: 40,
   //                   color: const Color(0xFFe06287),
   //
   //                   onPressed: () {
   //                     // Navigator.push(
   //                     //   context,
   //                     //   MaterialPageRoute(builder: (context) => ForgotPassword()),
   //                     // );
   //                   },
   //                   child: Text(
   //                     "Create New Account",
   //                     textAlign: TextAlign.center,
   //                     style: TextStyle(
   //                       color: Colors.white,
   //                       fontSize: 15,
   //                       fontWeight: FontWeight.w600,
   //                       fontFamily: 'Montserrat',
   //                     ),
   //                   ),
   //                 )
   //             ),
   //
   //
   //             Row(
   //               mainAxisAlignment: MainAxisAlignment.spaceEvenly,
   //               children: <Widget>[
   //                 Expanded(
   //                   child: Container(
   //                       margin: const EdgeInsets.only(top: 20.0),
   //                       alignment: FractionalOffset.bottomCenter,
   //                       child: GestureDetector(
   //
   //
   //                         onTap: (){
   //
   //                           Navigator.push(
   //                             context,
   //                             MaterialPageRoute(
   //                                 builder: (context) => LoginScreen()),
   //                           );
   //                         },
   //                         child: new Row(
   //                           mainAxisAlignment: MainAxisAlignment.center,
   //                           children: <Widget>[
   //                             new Text('Already have an account !',
   //                               style: TextStyle(
   //                                   color: Colors.black,
   //                                   fontSize: 15,
   //                                   fontWeight: FontWeight.w400,
   //                                   fontFamily: 'Montserrat'),
   //
   //                             ),
   //                             new Text(
   //                               ' Login.',
   //                               style: TextStyle(
   //                                   color: const Color(0xFFe06287),
   //                                   fontSize: 15,
   //                                   fontWeight: FontWeight.w400,
   //                                   fontFamily: 'Montserrat'),
   //                             )
   //                           ],
   //                         ),
   //
   //                       )),
   //                 ),
   //
   //
   //
   //
   //
   //               ],
   //             )
   //
   //
   //
   //
   //
   //
   //
   //
   //
   //
   //
   //           ],
   //
   //
   //
   //
   //
   //
   //         )
   //
   //       ),
   //
   //
   //       Container(
   //             margin: const EdgeInsets.only(bottom: 10),
   //
   //
   //             alignment: FractionalOffset.bottomCenter,
   //             child: Text("By clicking Create new account you agree to the following Terms & Condition.",
   //               textAlign: TextAlign.center,
   //               style: TextStyle(color: Colors.black,fontSize: 14,fontWeight: FontWeight.w800,fontFamily: 'Montserrat'),
   //             ),
   //       )
   //
   //
   //
   //
   //
   //
   //
   //
   //
   //
   //
   //
   //
   //
   //
   //
   //
   //
   //
   //
   //
   //     ],
   //
   //   ),
   //
   // ),
   //
   //
   //
   //  );



    return new SafeArea(
      child: Scaffold(
          backgroundColor: Colors.white,
          body: Scaffold(
            resizeToAvoidBottomPadding: true,
            body: new Stack(
              children: <Widget>[
                new SingleChildScrollView(
                  child: Column(

                      children: <Widget>[

                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,

                          children: <Widget>[

                            Flexible(
                              child: Container(
                                  margin: const EdgeInsets.only(top: 10.0, left: 2.0),
                                  alignment: FractionalOffset.topLeft,
                                  child: IconButton(
                                      icon: Icon(Icons.keyboard_arrow_left),
                                      color: Colors.black,
                                      iconSize: 30,
                                      onPressed: () => Navigator.of(context).pop())),
                            ),

                            Flexible(
                              child: Container(
                                margin: const EdgeInsets.only(top: 10.0, left: 2.0),
                                transform: Matrix4.translationValues(-100.0, 0.0, 0.0),
                                alignment: FractionalOffset.topCenter,
                                child: Text(
                                  "Create New Account",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 18,
                                      fontWeight: FontWeight.w600,
                                      fontFamily: 'Montserrat'),
                                ),
                              ),
                            ),


                          ],
                        ),

                        Container(
                          child:Container(
                            margin: const EdgeInsets.only(top: 50.0, left:22.0),
                            alignment: FractionalOffset.topLeft,
                            child: Text("Name",textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: const  Color(0xFF999999),
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'Montserrat'),),
                          ),
                        ),

                        Container(
                          alignment: FractionalOffset.topLeft,

                          margin: const EdgeInsets.only(
                              top: 5.0, left: 20.0, right: 20.0),
                          child: TextField(
                            autofocus: true,
                            keyboardType: TextInputType.name,

                            textInputAction: TextInputAction.next,
                            onSubmitted: (_) => FocusScope.of(context).nextFocus(),
                            style: TextStyle(fontSize: 18.0, color: Colors.black),
                            decoration: InputDecoration(
                              filled: true,
                              fillColor: const Color(0xFFf1f1f1),
                              hintText: 'Enter your full name',
                              contentPadding: const EdgeInsets.only(
                                  left: 14.0, bottom: 8.0, top: 8.0),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
                                borderRadius: BorderRadius.circular(5),
                              ),
                              enabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
                                borderRadius: BorderRadius.circular(5),
                              ),
                            ),
                          ),
                        ),


                        Container(
                          margin: const EdgeInsets.only(top: 5.0, left:22.0),
                          alignment: FractionalOffset.topLeft,
                          child: Text("Email id",textAlign: TextAlign.center,
                            style: TextStyle(
                                color: const  Color(0xFF999999),
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Montserrat'),),
                        ),

                        Container(
                          alignment: FractionalOffset.topLeft,

                          margin: const EdgeInsets.only(
                              top: 5.0, left: 20.0, right: 20.0),
                          child: TextField(
                            autofocus: true,
                            keyboardType: TextInputType.emailAddress,
                            focusNode: myFocusNode,textInputAction: TextInputAction.next,
                            onSubmitted: (_) => FocusScope.of(context).nextFocus(),
                            style: TextStyle(fontSize: 18.0, color: Colors.black),
                            decoration: InputDecoration(
                              filled: true,
                              fillColor: const Color(0xFFf1f1f1),
                              hintText: 'Enter your email id',
                              contentPadding: const EdgeInsets.only(
                                  left: 14.0, bottom: 8.0, top: 8.0),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
                                borderRadius: BorderRadius.circular(5),
                              ),
                              enabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
                                borderRadius: BorderRadius.circular(5),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.only(top: 5.0, left:22.0),
                          alignment: FractionalOffset.centerLeft,
                          child: Text("Phone Number",textAlign: TextAlign.center,
                            style: TextStyle(
                                color: const  Color(0xFF999999),
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Montserrat'),),
                        ),


                        Container(
                            alignment: FractionalOffset.centerLeft,

                            margin: const EdgeInsets.only(
                                top: 5.0, left: 20.0, right: 20.0),

                            child:Align(
                              alignment: Alignment.centerLeft,

                              child: TextField(


                                autofocus: true,
                                textAlign: TextAlign.left,
                                keyboardType: TextInputType.number,
                                textInputAction: TextInputAction.next,
                                onSubmitted: (_) => FocusScope.of(context).nextFocus(),
                                style: TextStyle(fontSize: 18.0, color: Colors.black,),
                                decoration: InputDecoration(
                                  prefixIcon: countryDropDown ,
                                  filled: true,
                                  fillColor: const Color(0xFFf1f1f1),
                                  hintText: 'Phone Number ',
                                  contentPadding: const EdgeInsets.only(
                                      left: 14.0, bottom: 8.0, top: 8.0),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
                                    borderRadius: BorderRadius.circular(5),
                                  ),
                                  enabledBorder: UnderlineInputBorder(
                                    borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
                                    borderRadius: BorderRadius.circular(5),
                                  ),
                                ),
                              ),


                            )

                        ),
                        Container(
                          margin: const EdgeInsets.only(top: 5.0, left:22.0),
                          alignment: FractionalOffset.centerLeft,
                          child: Text("PassWord",textAlign: TextAlign.center,
                            style: TextStyle(
                                color: const  Color(0xFF999999),
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Montserrat'),),
                        ),

                        Container(
                          alignment: FractionalOffset.centerLeft,

                          margin: const EdgeInsets.only(
                              top: 5.0, left: 20.0, right: 20.0),
                          child: TextField(

                            autofocus: true,
                            obscureText:true,
                            textInputAction: TextInputAction.next,
                            onSubmitted: (_) => FocusScope.of(context).nextFocus(),
                            style: TextStyle(fontSize: 18.0, color: Colors.black),
                            decoration: InputDecoration(
                              filled: true,
                              fillColor: const Color(0xFFf1f1f1),
                              hintText: 'Enter your Password',
                              contentPadding: const EdgeInsets.only(
                                  left: 14.0, bottom: 8.0, top: 8.0),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
                                borderRadius: BorderRadius.circular(5),
                              ),
                              enabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
                                borderRadius: BorderRadius.circular(5),
                              ),
                            ),
                          ),
                        ),
                        Container(

                            margin: const EdgeInsets.only(top: 20.0),
                            alignment: FractionalOffset.center,
                            // width: 500,
                            // height: 50,
                            // color: Colors.pink,

                            child: MaterialButton(
                              shape: new RoundedRectangleBorder(borderRadius: new BorderRadius.circular(5.0))
                              ,
                              minWidth: 300,
                              height: 40,
                              color: const Color(0xFFe06287),

                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => HomeScreen(2)),
                                );
                              },
                              child: Text(
                                "Create New Account",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'Montserrat',
                                ),
                              ),
                            )
                        ),


                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: <Widget>[
                            Expanded(
                              child: Container(
                                  margin: const EdgeInsets.only(top: 20.0),
                                  alignment: FractionalOffset.bottomCenter,
                                  child: GestureDetector(


                                    onTap: (){

                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => LoginScreen()),
                                      );
                                    },
                                    child: new Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: <Widget>[
                                        new Text('Already have an account !',
                                          style: TextStyle(
                                              color: Colors.black,
                                              fontSize: 15,
                                              fontWeight: FontWeight.w400,
                                              fontFamily: 'Montserrat'),

                                        ),
                                        new Text(
                                          ' Login.',
                                          style: TextStyle(
                                              color: const Color(0xFFe06287),
                                              fontSize: 15,
                                              fontWeight: FontWeight.w400,
                                              fontFamily: 'Montserrat'),
                                        )
                                      ],
                                    ),

                                  )),
                            ),





                          ],
                        ),
                        new Container(

                          child: SizedBox(height: 100,),

                        ),

                        new Container(
                            alignment: Alignment.bottomCenter,
                          child: Text("By clicking Create new account you agree to the following Terms & Condition.",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(color: Colors.black,fontSize: 14,fontWeight: FontWeight.w800,fontFamily: 'Montserrat'),
                          ),
                        ),


                      ]
                  ),
                ),



              ],
            ),
          )),
    );


  }


  @override
  void initState() {
    super.initState();

    myFocusNode = FocusNode();
  }

  @override
  void dispose() {
    // Clean up the focus node when the Form is disposed.
    myFocusNode.dispose();

    super.dispose();
  }


}

