import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'otpscreen.dart';

void main() {
  runApp(new MaterialApp(
    debugShowCheckedModeBanner: false,
    home: new ForgotPassword(),
  ));
}

class ForgotPassword extends StatefulWidget {
  @override
  _ForgotPassword createState() => new _ForgotPassword();
}

class _ForgotPassword extends State<ForgotPassword> {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        resizeToAvoidBottomPadding: true,
        backgroundColor: Colors.white,
        body: Container(
            child: Column(children: <Widget>[
          Expanded(
            child: ListView(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Flexible(
                      child: Container(
                          margin: const EdgeInsets.only(top: 10.0, left: 2.0),
                          alignment: FractionalOffset.topLeft,
                          child: IconButton(
                              icon: Icon(Icons.keyboard_arrow_left),
                              color: Colors.black,
                              iconSize: 30,
                              onPressed: () => Navigator.of(context).pop())),
                    ),
                    Flexible(
                      child: Container(
                        margin: const EdgeInsets.only(top: 10.0, left: 2.0),
                        transform: Matrix4.translationValues(-100.0, 0.0, 0.0),
                        alignment: FractionalOffset.topCenter,
                        child: Text(
                          "Forgot password",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                        ),
                      ),
                    )
                  ],
                ),
                Container(
                  child: Container(
                    margin: const EdgeInsets.only(top: 50.0, left: 0.0),
                    alignment: FractionalOffset.center,
                    child: Image.asset(
                      "images/forgotpassword.png",
                      width: 100,
                      height: 100,
                      alignment: Alignment.center,
                    ),
                  ),
                ),
                Container(
                    margin: const EdgeInsets.only(top: 70.0, left: 0.0),
                    alignment: FractionalOffset.center,
                    child: Text(
                      'Forgot Password !',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Montserrat'),
                    )),
                Container(
                    margin: const EdgeInsets.only(top: 2.0, left: 0.0),
                    alignment: FractionalOffset.center,
                    child: Text(
                      'Don\'t worry, we will find your account',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 15,
                          fontWeight: FontWeight.w300,
                          fontFamily: 'Montserrat'),
                    )),
                Container(
                  margin: const EdgeInsets.only(top: 50.0, left: 50.0),
                  alignment: FractionalOffset.topLeft,
                  child: Text(
                    "Email Id",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: const Color(0xFF999999),
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Montserrat'),
                  ),
                ),
                Container(
                  alignment: FractionalOffset.topLeft,
                  margin:
                      const EdgeInsets.only(top: 5.0, left: 45.0, right: 30.0),
                  child: TextField(
                    keyboardType: TextInputType.emailAddress,
                    autofocus: false,
                    style: TextStyle(fontSize: 18.0, color: Colors.black),
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: const Color(0xFFf1f1f1),
                      hintText: 'Enter your email id',
                      contentPadding: const EdgeInsets.only(
                          left: 14.0, bottom: 8.0, top: 8.0),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
                        borderRadius: BorderRadius.circular(5),
                      ),
                      enabledBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                  ),
                ),
                Container(
                    margin: const EdgeInsets.only(top: 20.0),
                    alignment: FractionalOffset.center,
                    // width: 500,
                    // height: 50,
                    // color: Colors.pink,

                    child: MaterialButton(
                      shape: new RoundedRectangleBorder(
                          borderRadius: new BorderRadius.circular(5.0)),
                      minWidth: 300,
                      height: 40,
                      color: const Color(0xFFe06287) ,
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => OtpScreen()),
                        );
                      },
                      child: Text(
                        "Send me OTP",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Montserrat',
                        ),
                      ),
                    )),
              ],
            ),
          ),
         Container(
            margin: const EdgeInsets.only(bottom: 2, top: 10),
            alignment: FractionalOffset.bottomCenter,
            child: Text(
              "Please check your email. ",
              textAlign: TextAlign.center,
              maxLines: 2,
              style: TextStyle(
                  color: Colors.grey,
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Montserrat'),
            ),
          ),


              Container(
            margin: const EdgeInsets.only(bottom: 8),
            alignment: FractionalOffset.bottomCenter,
            child: Text(
              "we will send you one OTP on your mail.",
              textAlign: TextAlign.center,
              maxLines: 2,
              style: TextStyle(
                  color: Colors.grey,
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Montserrat'),
            ),
          )

        ])));
  }
}
