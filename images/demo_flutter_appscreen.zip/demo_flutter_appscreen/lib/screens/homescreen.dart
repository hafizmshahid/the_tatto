import 'package:demo_flutter_appscreen/appbar/app_bar_only.dart';
import 'package:demo_flutter_appscreen/drawer/drawer_only.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../bottombar.dart';



void main() {
  runApp(new MaterialApp(
    debugShowCheckedModeBanner: false,
    home: new HomeScreen(2),
  ));
}



class HomeScreen extends StatefulWidget {
  int index;
  HomeScreen(this.index);


  @override
  _HomeScreen createState() => new _HomeScreen();
}




class _HomeScreen extends State<HomeScreen> {

  final GlobalKey<ScaffoldState> _drawerscaffoldkey =
      new GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {

    return new Scaffold(

        // backgroundColor: Colors.white,
        // appBar: appbar(context, 'Home',_drawerscaffoldkey),
        body: Scaffold(

            resizeToAvoidBottomPadding: true,

            //second scaffold
            key: _drawerscaffoldkey,

            //set gobal key defined above


            drawer:DrawerOnly(),

            bottomNavigationBar: new BottomBar(widget.index),
/*
            body: Container(
              child: Container(
                color: Colors.white,
               child: DefaultTabController(

                 length: 5,

                 child: new Scaffold(


                   body: TabBarView(

                     children: [
                       new Container(
                         color: Colors.yellow,
                       ),
                       new Container(color: Colors.orange,),
                       new Container(





                         color: Colors.lightGreen,
                       ),
                       new Container(
                         color: Colors.red,
                       ),
                       new Container(
                         color: Colors.pink,
                       ),
                     ],
                   ),
                   bottomNavigationBar: new TabBar(
                     tabs: [
                       Tab(
                         icon: new Icon(Icons.calendar_today),
                       ),
                       Tab(
                         icon: new Icon(Icons.location_searching),
                       ),
                       Tab(
                         icon: new Icon(Icons.home),
                       ),
                       Tab(icon: new Icon(Icons.notifications),),
                       Tab(icon: new Icon(Icons.person),)
                     ],
                     labelColor: Colors.white,
                     unselectedLabelColor: Colors.white,
                     indicatorSize: TabBarIndicatorSize.label,
                     indicatorPadding: EdgeInsets.all(1.0),
                     indicatorColor: Colors.white,
                   ),

                   backgroundColor: const Color(0xFFe06287),
                 ),




               )








              ),

                // your main content
                )
*/
        )
    );
  }




}
