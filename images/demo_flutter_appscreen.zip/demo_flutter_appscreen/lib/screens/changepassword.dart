import 'package:flutter/material.dart';

import 'changepassworddone.dart';


void main() {
  runApp(new MaterialApp(
    debugShowCheckedModeBanner: false,
    home: new ChangePassword(),

  ));
}

class ChangePassword extends StatefulWidget {
  @override
  _ChangePassword createState() => new _ChangePassword();
}
class _ChangePassword extends State<ChangePassword> {
  @override
  Widget build(BuildContext context) {




    return new Scaffold(

        resizeToAvoidBottomPadding : true,
        backgroundColor: Colors.white,

        body: Container(

          child: Stack(

            children: <Widget>[

              Expanded(
                child: ListView(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Flexible(
                          child:Container(
                              margin: const EdgeInsets.only(top: 10.0, left:2.0),
                              alignment: FractionalOffset.topLeft,
                              child: IconButton(
                                  icon: Icon(Icons.keyboard_arrow_left),
                                  color: Colors.black,iconSize: 30,
                                  onPressed: () => Navigator.of(context).pop()
                              )
                          ),
                        ),
                        Flexible(
                          child: Container(
                            margin: const EdgeInsets.only(top: 10.0, left:2.0),
                            transform: Matrix4.translationValues(-60.0, 0.0, 0.0),
                            alignment: FractionalOffset.topLeft,
                            child: Text("Change Password",textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'Montserrat'),),
                          ),
                        )
                      ],





                    ),

                    Container(
                      child: Container(
                        margin: const EdgeInsets.only(top: 50.0, left: 0.0),
                        alignment: FractionalOffset.center,
                        child: Image.asset(
                          "images/changepassword.png",
                          width: 100,
                          height: 100,
                          alignment: Alignment.center,
                        ),
                      ),
                    ),
                    Container(
                        margin: const EdgeInsets.only(top: 70.0, left: 0.0),
                        alignment: FractionalOffset.center,
                        child: Text(
                          'Set New Password',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'Montserrat'),
                        )),
                    Container(
                        margin: const EdgeInsets.only(top: 5.0, left: 0.0),
                        alignment: FractionalOffset.center,
                        child: Text(
                          'set new password and forgot old one.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              fontFamily: 'Montserrat'),
                        )),
                    Container(
                      margin: const EdgeInsets.only(top: 50.0, left: 50.0),
                      alignment: FractionalOffset.topLeft,
                      child: Text(
                        "New Password",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: const Color(0xFF999999),
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Montserrat'),
                      ),
                    ),
                    Container(
                      alignment: FractionalOffset.topLeft,
                      margin:
                      const EdgeInsets.only(top: 5.0, left: 45.0, right: 30.0),
                      child: TextField(
                        obscureText: true,
                        autofocus: false,
                        style: TextStyle(fontSize: 18.0, color: Colors.black),
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: const Color(0xFFf1f1f1),
                          hintText: 'New Password',
                          contentPadding: const EdgeInsets.only(
                              left: 14.0, bottom: 8.0, top: 8.0),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
                            borderRadius: BorderRadius.circular(5),
                          ),
                          enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
                            borderRadius: BorderRadius.circular(5),
                          ),
                        ),
                      ),
                    ),

                    Container(
                      margin: const EdgeInsets.only(top: 10.0, left: 50.0),
                      alignment: FractionalOffset.topLeft,
                      child: Text(
                        "Confirm Password",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: const Color(0xFF999999),
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Montserrat'),
                      ),
                    ),
                    Container(
                      alignment: FractionalOffset.topLeft,
                      margin:
                      const EdgeInsets.only(top: 5.0, left: 45.0, right: 30.0),
                      child: TextField(
                        obscureText: true,
                        autofocus: false,
                        style: TextStyle(fontSize: 18.0, color: Colors.black),
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: const Color(0xFFf1f1f1),
                          hintText: 'Confirm Password',
                          contentPadding: const EdgeInsets.only(
                              left: 14.0, bottom: 8.0, top: 8.0),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
                            borderRadius: BorderRadius.circular(5),
                          ),
                          enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: const Color(0xFFf1f1f1)),
                            borderRadius: BorderRadius.circular(5),
                          ),
                        ),
                      ),
                    ),
                    Container(
                        margin: const EdgeInsets.only(top: 20.0),
                        alignment: FractionalOffset.center,
                        // width: 500,
                        // height: 50,
                        // color: Colors.pink,

                        child: MaterialButton(
                          shape: new RoundedRectangleBorder(
                              borderRadius: new BorderRadius.circular(5.0)),
                          minWidth: 300,
                          height: 40,
                          color: const Color(0xFFe06287) ,
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => ChangePasswordDone()),
                            );
                          },
                          child: Text(
                            "Change Password",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat',
                            ),
                          ),
                        )),










                  ],




                )



              ),



            ],


          ),


    ),
    );

  }




}

