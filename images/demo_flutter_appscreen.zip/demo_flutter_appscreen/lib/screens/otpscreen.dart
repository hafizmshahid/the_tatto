import 'dart:async';
import 'changepassword.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pin_code_text_field/pin_code_text_field.dart';

import 'loginscreen.dart';

void main() {
  runApp(new MaterialApp(
    debugShowCheckedModeBanner: false,
    home: new OtpScreen(),

  ));
}


class OtpScreen extends StatefulWidget {
  @override
  _OtpScreen createState() => new _OtpScreen();
}

class _OtpScreen extends State<OtpScreen> {
  Timer _timer;
  int _start = 60;


  @override
  Widget build(BuildContext context) {
    return new Scaffold(

        resizeToAvoidBottomPadding : true,
        backgroundColor: Colors.white,

        body: Container(

        child: Stack(

        children: <Widget>[



         Expanded(

            child: ListView(

              children: [

                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[


                    Flexible(
                      child:Container(
                          margin: const EdgeInsets.only(top: 10.0, left:2.0),

                          alignment: FractionalOffset.topLeft,
                          child: IconButton(
                              icon: Icon(Icons.keyboard_arrow_left),
                              color: Colors.black,iconSize: 30,
                              onPressed: () => Navigator.of(context).pop()


                          )

                      ),

                    ),

                   // Defaults to a flex of one.

                    // Gives twice the space between Middle and End than Begin and Middle.


                    Flexible(


                      child: Container(
                        margin: const EdgeInsets.only(top: 10.0, left:2.0),
                        transform: Matrix4.translationValues(-50.0, 0.0, 0.0),
                        alignment: FractionalOffset.topLeft,
                        child: Text("Verification",textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),),
                      ),

                    )

                  ],





            ),








                Container(
                  child:Container(
                    margin: const EdgeInsets.only(top: 100.0, left:0.0),
                    alignment: FractionalOffset.center,
                    child: Text("OTP",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.w800,fontFamily: 'Montserrat'),
                    ),
                  ),
                ),
                Container(
                  child:Container(
                    margin: const EdgeInsets.only(top: 1.0, left:0.0),
                    alignment: FractionalOffset.center,
                    child: Text("Set your otp here.",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.black,fontSize: 15,fontWeight: FontWeight.w500,fontFamily: 'Montserrat'),
                    ),
                  ),
                ),
                Container(
                  child:Container(
                    margin: const EdgeInsets.only(top: 30.0, left:0.0),
                    alignment: FractionalOffset.center,
                    child: Text("00:"+"$_start",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: const Color(0xFF999999),fontSize: 16,fontWeight: FontWeight.w800,fontFamily: 'Montserrat'),
                    ),
                  ),
                ),

                Container(
                  padding: const EdgeInsets.all(5.0),
                  margin: const EdgeInsets.only(top: 20.0, left:0.0),

                  alignment: FractionalOffset.center,
                  child: PinCodeTextField(
                    autofocus: true,
                    hideCharacter: false,
                    highlight: false,
                    pinBoxColor: const Color(0xFFf1f1f1),
                    highlightColor: const Color(0xFFf1f1f1),
                    defaultBorderColor: const Color(0xFFf1f1f1),
                    hasTextBorderColor: const Color(0xFFf1f1f1),
                    pinBoxBorderWidth: 2,
                    maxLength: 4,
                    onTextChanged: (text) {
                      setState(() {
                        print('hi');
                      });
                    },
                    onDone: (text) {
                      print("DONE $text");
                    },
                    pinBoxWidth: 50,
                    pinBoxHeight: 50,
                    pinBoxOuterPadding: const EdgeInsets.all(10.0),
                    pinBoxRadius: 10,
                    hasUnderline: false,



                    wrapAlignment: WrapAlignment.center,
                    pinBoxDecoration:
                    ProvidedPinBoxDecoration.defaultPinBoxDecoration,
                    pinTextStyle: TextStyle(fontSize: 22.0,color: const Color(0xFF999999)),
                    pinTextAnimatedSwitcherTransition:
                    ProvidedPinBoxTextAnimation.defaultNoTransition,
                    highlightPinBoxColor: const Color(0xFFf1f1f1),
                    pinTextAnimatedSwitcherDuration:
                    Duration(milliseconds: 300),
//                    highlightAnimation: true,
                    highlightAnimationBeginColor: const Color(0xFFf1f1f1),
                    highlightAnimationEndColor: const Color(0xFFf1f1f1),
                    keyboardType: TextInputType.number,

                  ),  // end PinEntryTextField()
                ),

                Container(

                    margin: const EdgeInsets.only(top: 10.0),
                    alignment: FractionalOffset.center,
                    // width: 500,
                    // height: 50,
                    // color: Colors.pink,

                    child: MaterialButton(
                      shape: new RoundedRectangleBorder(borderRadius: new BorderRadius.circular(5.0))
                      ,
                      minWidth: 300,
                      height: 40,
                      color: const Color(0xFFe06287),

                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => ChangePassword()),
                        );
                      },
                      child: Text(
                        "Next",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Montserrat',
                        ),
                      ),
                    )
                ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Expanded(
                      child: Container(
                          margin: const EdgeInsets.only(top: 20.0),
                          alignment: FractionalOffset.bottomCenter,
                          child: GestureDetector(


                            onTap: (){

                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => LoginScreen()),
                              );
                            },
                            child: new Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                new Text('Don\'t receive OPT ?',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 15,
                                      fontWeight: FontWeight.w600,
                                      fontFamily: 'Montserrat'),

                                ),
                                new Text(
                                  ' Resend.',
                                  style: TextStyle(
                                      color: const Color(0xFFe06287),
                                      fontSize: 15,
                                      fontWeight: FontWeight.w600,
                                      fontFamily: 'Montserrat'),
                                )
                              ],
                            ),

                          )),
                    ),





                  ],
                )

              ],





            ),

          )

       ] )
    )
    );






  }


  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    startTimer();
  }
  void startTimer() {
    if (_timer != null) {
      _timer.cancel();
      _timer = null;
    } else {
      _timer = new Timer.periodic(
        const Duration(seconds: 1),
            (Timer timer) => setState(
              () {
            if (_start < 1) {
              timer.cancel();
            } else {
              _start =
                  _start - 1;
            }
          },
        ),
      );
    }
  }

}