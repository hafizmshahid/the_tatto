import 'package:demo_flutter_appscreen/main.dart';
import 'package:demo_flutter_appscreen/screens/registerScreen.dart';
import 'package:flutter/material.dart';

import 'forgotpassword.dart';
import 'homescreen.dart';


void main() {
  runApp(new MaterialApp(
    debugShowCheckedModeBanner: false,
    home: new LoginScreen(),
  ));
}

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreen createState() => new _LoginScreen();

}

class _LoginScreen extends State<LoginScreen> {
  FocusNode myFocusNode;


  @override
  Widget build(BuildContext context) {
    return new SafeArea(
      child: Scaffold(
        body: Stack(
            children: <Widget>[
              new Container(
                decoration: BoxDecoration(
                  color: const Color(0xff7c94b6),
                  image: DecorationImage(
                      image: AssetImage("images/the_barber.jpg"),
                      fit: BoxFit.cover,
                      colorFilter: new ColorFilter.mode(
                          Colors.blue.withOpacity(0.19), BlendMode.dstATop)),
                ),
              ),

              new ListView(

                children: [


                  Container(
                    child: Container(
                      margin: const EdgeInsets.only(top: 110.0, left: 100.0),
                      alignment: FractionalOffset.topLeft,
                      child: Text(
                        "The",
                        textAlign: TextAlign.end,
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Montserrat'),
                      ),
                    ),
                  ),



                  Container(
                    margin: const EdgeInsets.only(top: 0.0, left: 130.0),
                    alignment: FractionalOffset.topLeft,
                    child: Text(
                      "BARBER.",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 35,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Montserrat'),
                    ),
                  ),

                  Container(
                    margin: const EdgeInsets.only(
                        top: 20.0, left: 10.0, right: 10.0),
                    alignment: FractionalOffset.topCenter,
                    child: TextField(
                      focusNode: myFocusNode,textInputAction: TextInputAction.next,

                      onSubmitted: (_) => FocusScope.of(context).nextFocus(),

                      keyboardType: TextInputType.emailAddress,
                      autofocus: false,
                      style: TextStyle(fontSize: 20.0, color: Colors.white),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: const Color(0xFF939DA1),
                        hintText: 'Email id',
                        contentPadding: const EdgeInsets.only(
                            left: 14.0, bottom: 8.0, top: 8.0),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: const Color(0xFF939DA1)),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: const Color(0xFF939DA1)),
                          borderRadius: BorderRadius.circular(5),
                        ),
                      ),
                    ),
                  ),

                  Container(
                    margin: const EdgeInsets.only(
                        top: 20.0, left: 10.0, right: 10.0),
                    alignment: FractionalOffset.topCenter,
                    child: TextField(

                      obscureText: true,
                      autofocus: false,
                      style: TextStyle(fontSize: 20.0, color: Colors.white),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: const Color(0xFF939DA1),
                        hintText: 'Password',
                        contentPadding: const EdgeInsets.only(
                            left: 14.0, bottom: 8.0, top: 8.0),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: const Color(0xFF939DA1)),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: const Color(0xFF939DA1)),
                          borderRadius: BorderRadius.circular(5),
                        ),
                      ),
                    ),
                  ),

                  Container(
                      margin: const EdgeInsets.only(top:10,right: 15.0),
                      alignment: FractionalOffset.centerRight,
                      child: FlatButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ForgotPassword()),
                          );
                        },
                        child: Text(
                          "Forgot Password?",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w400,
                              fontFamily: 'Montserrat'),
                        ),
                      )
                  ),

                  Container(

                      margin: const EdgeInsets.only(top: 5.0),
                      alignment: FractionalOffset.center,
                      // width: 500,
                      // height: 50,
                      // color: Colors.pink,

                      child: MaterialButton(
                        minWidth: 300,
                        height: 35,
                        color: const Color(0xFFe06287),

                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => HomeScreen(2)),
                          );
                        },
                        child: Text(
                          "Login",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Montserrat',
                          ),
                        ),
                      )
                  ),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      Expanded(
                        child: Container(
                            margin: const EdgeInsets.only(top: 20),
                            alignment: FractionalOffset.bottomCenter,
                            child: GestureDetector(


                              onTap: (){

                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => RegisterScreen()),
                                );
                              },
                              child: new Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  new Text('Don\'t have an account?',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 15,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: 'Montserrat'),

                                  ),
                                  new Text(
                                    ' Register.',
                                    style: TextStyle(
                                        color: const Color(0xFFe06287),
                                        fontSize: 15,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: 'Montserrat'),
                                  )
                                ],
                              ),

                            )),
                      ),


                    ],
                  ),

                ],

              )

            ]
        ),
      ),
    );
  }
  @override
  void initState() {
    super.initState();

    myFocusNode = FocusNode();
  }

  @override
  void dispose() {
    // Clean up the focus node when the Form is disposed.
    myFocusNode.dispose();

    super.dispose();
  }

}
