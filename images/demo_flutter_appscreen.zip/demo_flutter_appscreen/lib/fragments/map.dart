import 'package:demo_flutter_appscreen/appbar/app_bar_only.dart';
import 'package:demo_flutter_appscreen/drawer/drawer_only.dart';
import 'package:flutter/material.dart';

import '../bottombar.dart';

class Map extends StatelessWidget {

  final GlobalKey<ScaffoldState> _drawerscaffoldkey =
  new GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Scaffold(

        backgroundColor: Colors.white,
        appBar: appbar(context, 'Near By you',_drawerscaffoldkey),
        body: Scaffold(

            resizeToAvoidBottomPadding: true,

            //second scaffold
            key: _drawerscaffoldkey,

            //set gobal key defined above


            drawer: new DrawerOnly(),
            // bottomNavigationBar: new BottomBar(),
            // bottomNavigationBar: new BottomBar(),
            body: SingleChildScrollView(
              child: Container(


                color: Colors.white,


                child: Text("hii"),

              ),

              // your main content
            )
        )
    );


  }

}