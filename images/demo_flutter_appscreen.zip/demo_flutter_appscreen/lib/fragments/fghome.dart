import 'package:carousel_slider/carousel_slider.dart';
import 'package:demo_flutter_appscreen/appbar/app_bar_only.dart';
import 'package:demo_flutter_appscreen/drawer/drawer_only.dart';
import 'package:demo_flutter_appscreen/drawerscreen/top_services.dart';
import 'package:demo_flutter_appscreen/separator/separator.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';


class FgHome extends StatefulWidget {
  FgHome({Key key, this.title}) : super(key: key);


  final String title;

  @override
  _FgHome createState() => _FgHome();

}


class _FgHome extends State<FgHome> {

  CarouselSlider carouselSlider;
  int _current = 1;
  List imgList = [
    'https://images.unsplash.com/photo-1502117859338-fd9daa518a9a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60',
    'https://images.unsplash.com/photo-1554321586-92083ba0a115?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60',
    'https://images.unsplash.com/photo-1536679545597-c2e5e1946495?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60',

  ];

  List userdetails = [
    {"first_name": "1", "last_name": "11", "imageURL": "Salon"},
    {"first_name": "2", "last_name": "11", "imageURL": "Styling"},
    {"first_name": "3", "last_name": "11", "imageURL": "Mackup"},
    {"first_name": "3", "last_name": "11", "imageURL": "Shaving"},
    {"first_name": "3", "last_name": "11", "imageURL": "Shampoo"},

  ];

  List<T> map<T>(List list, Function handler) {
    List<T> result = [];
    for (var i = 0; i < list.length; i++) {
      result.add(handler(i, list[i]));
    }
    return result;
  }

  final GlobalKey<ScaffoldState> _drawerscaffoldkey =
  new GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Scaffold(

        backgroundColor: Colors.white,
        appBar: appbar(context, 'Home',_drawerscaffoldkey),
        resizeToAvoidBottomPadding: true,
        key: _drawerscaffoldkey,
        drawer: new DrawerOnly(),
        body: SingleChildScrollView(

            child: Column(
              mainAxisSize: MainAxisSize.min,

              children: [


                Container(
                  padding: const EdgeInsets.only(left: 12,right: 12),


                  child:
                  MySeparator(color: Colors.grey),


                ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,

                  children: <Widget>[

                    Flexible(
                      child: Container(
                          margin: const EdgeInsets.only(top: 0.0, left: 2.0),
                          alignment: FractionalOffset.topLeft,
                          child: IconButton(
                              icon: Icon(Icons.location_searching,
                                size: 20,
                                  color: const Color(0xFFe06287),),
                              color: Colors.black,

                              iconSize: 30,
                              onPressed: () => Navigator.of(context).pop())),
                    ),

                    Flexible(
                      child: Container(
                        margin: const EdgeInsets.only(top: 0.0, left: 2.0),
                        transform: Matrix4.translationValues(-130.0, 0.0, 0.0),
                        alignment: FractionalOffset.topLeft,
                        child: Text(
                          "vishwashanti marg, pune",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 15,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                        ),
                      ),
                    ),


                  ],
                ),


                Container(
                  padding: const EdgeInsets.only(left: 12,right: 12),
                  child:
                  MySeparator(color: Colors.grey),
                ),


                //Code for image slider


                Container(
                  width: 400,
                  height: 200,
                  alignment: Alignment.topCenter,
                 margin: EdgeInsets.only(top:10,left: 20,right: 20),


                  child: Container(
                    child: Stack(
                      alignment: Alignment.bottomCenter,
                      children: <Widget>[


                        Flexible(
                          child: CarouselSlider(


                            options: CarouselOptions(
                              height: 180,
                              viewportFraction: 1.0,
                              onPageChanged: (index,index1) {
                                setState(() {
                                  _current = index;
                                });
                              },




                            ) ,
                            items: imgList.map((imgUrl) {
                              return Builder(
                                builder: (BuildContext context) {
                                  return Container(

                                      child:Stack(

                                        children: <Widget>[

                                          Material(
                                            color: Colors.white,
                                            borderRadius: BorderRadius.circular(10.0),
                                            elevation: 2.0,
                                            clipBehavior: Clip.antiAliasWithSaveLayer,
                                            type: MaterialType.transparency,
                                            child: Image.network( imgUrl,

                                              height: 200,
                                              width: 500,
                                              fit: BoxFit.fitWidth,
                                            ),


                                          ),

                                          Center(
                                            child: Text('Book The Best Barber.',style: TextStyle(color: Colors.white,fontSize: 26,fontWeight: FontWeight.w800),),

                                          )

                                        ],
                                      )



                                  );
                                },
                              );
                            }).toList(),
                          ),
                        ),
                        Flexible(
                          child:Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: map<Widget>(imgList, (index, url) {
                              return Container(
                                alignment: Alignment.bottomCenter,
                                width: 10.0,
                                height: 10.0,
                                margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 2.0),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _current == index ? Colors.redAccent : Colors.white,
                                ),
                              );
                            }),
                          ),

                        )
                      ],
                    ),
                  ),
                ),

                Container(
                  margin: EdgeInsets.only(left: 20.0),
                  alignment: Alignment.topLeft,

                  child: Text('Top Salon',style: TextStyle(
                      color: Colors.black,
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Montserrat'),),
                  ),




                    Container(
                        margin: EdgeInsets.only(top: 5.0),
                        color: Colors.white,
                        height: 220,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemBuilder: (BuildContext context, int index) {
                            return new UserWidget(
                              firstName: userdetails[index]['first_name'],
                              lastName: userdetails[index]['last_name'],
                              // imageURL: userdetails[index]['image_url'],
                            );
                          },
                          itemCount: userdetails.length,
                        )



                ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,

                  children: <Widget>[



                    Flexible(
                      child:    Container(
                        margin: EdgeInsets.only(left: 20.0),
                        alignment: Alignment.topLeft,
                        child: Text('Top Services',style: TextStyle(
                            color: Colors.black,
                            fontSize: 18,
                            fontWeight: FontWeight.w600,

                            fontFamily: 'Montserrat'),),
                      ),
                    ),

                    Flexible(
                      child: Container(
                          margin: const EdgeInsets.only(top: 0.0, left: 2.0),
                          alignment: FractionalOffset.topRight,
                          child: IconButton(
                              icon: Icon(Icons.arrow_forward_sharp,
                                size: 20,

                              ),
                              color: Colors.black,

                              iconSize: 30,
                                onPressed: () => {
                             Navigator.of(context).push(MaterialPageRoute(builder: (context) => TopService(0,"Explore All"))),
                                },
                    ),

                      ),
                    ),
                  ],
                ),
                Container(
                  color: const Color(0xFFf9f9f9),
                  margin: EdgeInsets.only(top: 5.0,left: 10,bottom: 20),
                  height: 100,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,

                    itemCount: userdetails.length,
                    itemBuilder: (BuildContext context, int index) {


                      return ServiceWidget(
                          firstName: userdetails[index]['first_name'],
                          lastName: userdetails[index]['last_name'],
                          imageURL: userdetails[index]['imageURL'],
                          index: index,


                      );
                    },

                      // return new ServiceWidget(
                      //   firstName: userdetails[index]['first_name'],
                      //   lastName: userdetails[index]['last_name'],
                      //   imageURL: userdetails[index]['imageURL'],
                      // );



                  ),
                ),

                // Container(
                //
                //     margin: EdgeInsets.only(top: 15.0,bottom: 15.0),
                //     color: Colors.yellowAccent,
                //     height: 100,
                //     width: 100,
                //     child: ListView.builder(
                //       scrollDirection: Axis.horizontal,
                //       itemBuilder: (BuildContext context, int index) {
                //         return new ServiceWidget(
                //           firstName: userdetails[index]['first_name'],
                //           lastName: userdetails[index]['last_name'],
                //           // imageURL: userdetails[index]['image_url'],
                //         );
                //       },
                //       itemCount: userdetails.length,
                //     )
                //
                //
                //
                // ),










              ],

              // your main content
            )
        )
    );


  }



}
class UserWidget extends StatelessWidget {
  final String firstName;
  final String lastName;
  final String imageURL;

  const UserWidget({Key key, this.firstName, this.lastName, this.imageURL})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return new Container(
      width: 210,
      // height: 200,
//       child: Card(
//         color: Colors.grey,
//         child: Container(
//           width: 10,
//           height: 10,
//           child: Center(child: Text("First "+ firstName, style: TextStyle(color: Colors.white, fontSize: 36.0),)),
//         ),
// //
//
//     ),

      child:Container(
        // height: 150,




          margin: EdgeInsets.only(left: 5,right: 5,bottom: 0.0),

          child: Card(

              child:Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[

                  Expanded(

                    child:ListView(

                      children: [

                        Stack(
                          children:<Widget>[

                            Expanded(child: Container(



                              height:130,



                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10.0),
                                image: DecorationImage(
                                  image: AssetImage(
                                      "images/the_barber.jpg"),
                                  fit: BoxFit.fitWidth,
                                  alignment: Alignment.topCenter,
                                ),
                              ),





                            ),
                            ),

                            // Expanded(
                            //   child: Container(
                            //
                            //
                            //     alignment: Alignment.bottomRight,
                            //     child: RaisedButton(
                            //
                            //
                            //       child: Text('Book',style: TextStyle(color: Colors.white,backgroundColor: Colors.pinkAccent),),
                            //
                            //
                            //     ),
                            //
                            //
                            // ),
                            // )



                          ],




                        )

                        ,

                        Container(

                            child:Row(

                              children: <Widget>[

                                Expanded(
                                  child: Container(
                                    color: Colors.white,
                                    alignment: Alignment.topLeft,
                                    margin: EdgeInsets.only(left: 10,top:20),

                                    child: Text('Barberque',style: TextStyle(color: Colors.black,fontWeight: FontWeight.w600,fontSize: 14),),



                                  ),
                                ),

                                Expanded(
                                  child: Container(
                                      color: Colors.white,
                                      alignment: Alignment.topRight,
                                      margin: EdgeInsets.only(left: 10,top:20,right: 10),

                                      child: RichText(
                                        text: TextSpan(
                                          children: [

                                            WidgetSpan(
                                              child: Icon(Icons.star, size: 16,color: Colors.yellow,),
                                            ),
                                            TextSpan(
                                                text: "4.0 ",
                                                style: TextStyle(color: Colors.yellow,fontSize: 14,fontWeight: FontWeight.w500)
                                            ),

                                          ],
                                        ),
                                      )



                                  ),
                                ),




                              ],
                            )




                        ),
                        Container(

                            transform: Matrix4.translationValues(0.0, 0.0, 0.0),
                            color: Colors.white,
                            alignment: Alignment.topCenter,
                            margin: EdgeInsets.only(left: 10,top:0.0,right: 10),

                            child: Text("vishwashanti marg, near green lnn fast food,pune",style: TextStyle(fontSize: 13,color: Colors.black)
                            )
                        ),





                      ],

                    ),






                  ),



                  /*  Expanded(



                  child: Container(

                      transform: Matrix4.translationValues(0.0, 0.0, 0.0),
                      color: Colors.white,
                      alignment: Alignment.topCenter,
                      margin: EdgeInsets.only(left: 10,top:0.0,right: 10),

                      child: Text("vishwashanti marg, near green lnn fast food,pune",

                      )




                ),





              )*/





                ],

              )



            // children: <Widget>[
            //   Expanded(




            // ),

            // Expanded(









          )
        // ],
      ),






    );
  }
}


class ServiceWidget extends StatelessWidget {
  final String firstName;
  final String lastName;
  final String imageURL;
  final int index;

  const ServiceWidget({Key key, this.firstName, this.lastName, this.imageURL, this.index})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return  Container(
      alignment: Alignment.topCenter,

        width: 100,
        height: 50,

        child:GestureDetector(
          onTap: (){
            print(index);

            Navigator.of(context).push(MaterialPageRoute(builder: (context) => TopService(index+1,this.imageURL)));

          } ,
            child: Stack(
              children: <Widget>[
                Expanded(
                  child: Card(
                    color: Colors.white,
                    child: Container(
                      alignment: Alignment.topCenter,
                      child: Center(



                        child: Image.asset(
                          "images/changepassword.png",
                          width: 50,
                          height: 45,
                          color: const Color(0xFFe06287),
                        ),
                        // colorFilter: ColorFilter.mode(Colors.transparent, BlendMode.color),





                      ),


                    ),
                  ),
                ),

                Expanded(
                  child: Container(
                    alignment: Alignment.center,
                    margin: EdgeInsets.only(top: 70),
                    color: Colors.transparent,
                    child: Container(
                      child: Text(imageURL,style: TextStyle(
                            color: Colors.black,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            fontFamily: 'Montserrat'),),
                    ),
                  ),
                ),
              ],
            ),
    ),
        );






  }
}

