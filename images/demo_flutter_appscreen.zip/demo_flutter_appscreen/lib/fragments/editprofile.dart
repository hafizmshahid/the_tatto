import 'package:demo_flutter_appscreen/appbar/app_bar_only.dart';
import 'package:demo_flutter_appscreen/drawer/drawer_only.dart';
import 'package:demo_flutter_appscreen/separator/separator.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(new MaterialApp(
    debugShowCheckedModeBanner: false,
    home: new EditProfile(),
  ));
}

class EditProfile extends StatefulWidget {
  @override
  _EditProfile createState() => new _EditProfile();
}

class _EditProfile extends State<EditProfile> {
  final GlobalKey<ScaffoldState> _drawerscaffoldkey =
  new GlobalKey<ScaffoldState>();
  List appoinmentdatalist = [
    {
      "discount": "10%",
      "dark_color": const Color(0xFFffb5cc),
      "light_color": const Color(0xFFffc8de),
    },
    // {"discount": "50%", "dark_color": const Color(0xFFb5b8ff), "light_color": const Color(0xFFc8caff)},
    // {"discount": "30%", "dark_color": const Color(0xFFffb5b5), "light_color": const Color(0xFFffc8c8)},
  ];

  List appoinmentdatalist1 = [
    {
      "discount": "10%",
      "dark_color": const Color(0xFFffb5cc),
      "light_color": const Color(0xFFffc8de),
    },
    {
      "discount": "50%",
      "dark_color": const Color(0xFFb5b8ff),
      "light_color": const Color(0xFFc8caff)
    },
    {
      "discount": "30%",
      "dark_color": const Color(0xFFffb5b5),
      "light_color": const Color(0xFFffc8c8)
    },
  ];

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
      child: Scaffold(
          resizeToAvoidBottomPadding:false,
          backgroundColor: Colors.white,
          appBar: appbar(context, 'Edit Profile', _drawerscaffoldkey),

          key: _drawerscaffoldkey,

          //set gobal key defined above

          drawer: new DrawerOnly(),

          body: Padding(
              padding: EdgeInsets.all(10),
              child: ListView(
                children: <Widget>[
                  Container(
                    margin: EdgeInsets.only(left: 10, right: 10, top: 10),
                    height: 100,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      border:
                      Border.all(color: const Color(0xFFf1f1f1), width: 2),
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          child: Image.asset(
                            "images/roundprofile.png",
                            width: 90,
                            height: 90,
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 20),
                          // width: 150,
                          child: Center(
                            child: Text(
                              'Darshi Patel',
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                  fontFamily: 'Montserrat'),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 11, top: 25),
                    alignment: Alignment.topLeft,
                    child: Text(
                      'Personal Info',
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.w600,
                          fontSize: 18,
                          fontFamily: 'Montserrat'),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 20, top: 10),
                    alignment: Alignment.topLeft,
                    child: Text(
                      'Edit your name',
                      style: TextStyle(
                          color: const Color(0xFF999999),
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                          fontFamily: 'Montserrat'),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 10, top: 10, right: 10),
                    child: TextFormField(
                      autofocus: false,
                      initialValue: "Darshi Patel",
                      keyboardType: TextInputType.text,
                      textInputAction: TextInputAction.next,
                      // onSubmitted: (_) => FocusScope.of(context).nextFocus(),
                      style: TextStyle(
                          fontSize: 14.0,
                          color: Colors.black,
                          fontFamily: "Montserrat",
                          fontWeight: FontWeight.w600),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: const Color(0xFFf1f1f1),
                        hintText: 'Enter your Name',
                        contentPadding: const EdgeInsets.only(
                            left: 14.0, bottom: 8.0, top: 8.0),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                          BorderSide(color: const Color(0xFFf1f1f1)),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        enabledBorder: UnderlineInputBorder(
                          borderSide:
                          BorderSide(color: const Color(0xFFf1f1f1)),
                          borderRadius: BorderRadius.circular(5),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 20, top: 10),
                    alignment: Alignment.topLeft,
                    child: Text(
                      'Edit your EmailId',
                      style: TextStyle(
                          color: const Color(0xFF999999),
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                          fontFamily: 'Montserrat'),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 10, top: 10, right: 10),
                    child: TextFormField(
                      autofocus: false,
                      initialValue: "darshi123@gmail.com",
                      keyboardType: TextInputType.emailAddress,
                      textInputAction: TextInputAction.next,
                      // onSubmitted: (_) => FocusScope.of(context).nextFocus(),
                      style: TextStyle(
                          fontSize: 14.0,
                          color: Colors.black,
                          fontFamily: "Montserrat",
                          fontWeight: FontWeight.w600),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: const Color(0xFFf1f1f1),
                        hintText: 'Enter your EmailId',
                        contentPadding: const EdgeInsets.only(
                            left: 14.0, bottom: 8.0, top: 8.0),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                          BorderSide(color: const Color(0xFFf1f1f1)),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        enabledBorder: UnderlineInputBorder(
                          borderSide:
                          BorderSide(color: const Color(0xFFf1f1f1)),
                          borderRadius: BorderRadius.circular(5),
                        ),
                      ),
                    ),
                  ),


                  Container(
                    margin: EdgeInsets.only(left: 20, top: 10),
                    alignment: Alignment.topLeft,
                    child: Text(
                      'Edit your Contact Number',
                      style: TextStyle(
                          color: const Color(0xFF999999),
                          fontWeight: FontWeight.w600,
                          fontSize: 14.0,
                          fontFamily: 'Montserrat'),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 10, top: 10, right: 10),
                    child: TextFormField(
                      autofocus: false,
                      initialValue: "1234567890",
                      keyboardType: TextInputType.number,
                      textInputAction: TextInputAction.next,
                      // onSubmitted: (_) => FocusScope.of(context).nextFocus(),
                      style: TextStyle(
                          fontSize: 14.0,
                          color: Colors.black,
                          fontFamily: "Montserrat",
                          fontWeight: FontWeight.w600),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: const Color(0xFFf1f1f1),
                        hintText: 'Enter your Contact Number',
                        contentPadding: const EdgeInsets.only(
                            left: 14.0, bottom: 8.0, top: 8.0),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                          BorderSide(color: const Color(0xFFf1f1f1)),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        enabledBorder: UnderlineInputBorder(
                          borderSide:
                          BorderSide(color: const Color(0xFFf1f1f1)),
                          borderRadius: BorderRadius.circular(5),
                        ),
                      ),
                    ),
                  ),

                  Container(

                    margin: EdgeInsets.only(left: 10,top: 20,right: 10,bottom: 10),


                    child: MySeparator(),
                  ),

                  Container(
                    margin: EdgeInsets.only(left: 11, top: 15),
                    alignment: Alignment.topLeft,
                    child: Text(
                      'Manage Your Location',
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.w600,
                          fontSize: 18,
                          fontFamily: 'Montserrat'),
                    ),
                  ),

                  Container(
                    margin: EdgeInsets.only(left: 11, top: 5),
                    alignment: Alignment.topLeft,
                    child: Text(
                      '+ Add New Location',
                      style: TextStyle(
                          color: Colors.blue,
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                          fontFamily: 'Montserrat'),
                    ),
                  ),


                  Container(
                    margin: EdgeInsets.only(left: 11, top: 10),


                    child:   Container(
                      height: 60,


                      width: double.infinity,
                      margin: EdgeInsets.only(left: 10, top:00 ),

                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            margin: EdgeInsets.only(top: 5),
                            child: Icon(Icons.location_searching,size: 25,


                            ),
                          ),
                          Container(
                            height: 35,
                            transform: Matrix4.translationValues(-35.0, 5.0, 0.0),




                            child: Column(


                              children: [
                                Text(
                                  'Vishwashanti marg',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14,
                                      fontFamily: 'Montserrat'),
                                ),

                                Text(
                                  'Pune, Maharastra, india',
                                  style: TextStyle(
                                      color: Colors.grey,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 11,
                                      fontFamily: 'Montserrat'),
                                ),



                              ],

                            ),
                          ),
                            
                            Container(
                              margin: EdgeInsets.only(right: 10),
                                child: RichText(
                                  text: TextSpan(
                                    children: [

                                      WidgetSpan(
                                        child: Icon(Icons.delete, size: 14,
                                          color: const Color(0xFFff4040),),
                                      ),
                                      TextSpan(
                                          text: "Remove",
                                          style: TextStyle(color: const Color(0xFFff4040),
                                              fontSize: 12,
                                              fontWeight: FontWeight.w500)
                                      ),



                                    ],
                                  ),
                                )

                            ),


                        ],
                      ),
                    ),







                  ),



                ],
              )
          )
      ),
    );
  }
}

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Container(

        // child: CustomView(),

      ),
    );
  }
}
