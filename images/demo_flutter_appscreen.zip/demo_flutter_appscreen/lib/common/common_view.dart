import 'package:demo_flutter_appscreen/screens/homescreen.dart';
import 'package:flutter/material.dart';


class CustomView extends StatefulWidget {
  const CustomView({Key key}) : super(key: key);

  @override
  _CustomView createState() => _CustomView();
}

class _CustomView extends State<CustomView> {
  @override
  // implement wantKeepAlive


  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      //    bottomNavigationBar: new BottomBar1(),


      child: Container(
        color: const Color(0xFFe06287),
            alignment: FractionalOffset.bottomCenter,
            height: 50,





            child:Row(

              children: <Widget>[
                Expanded(
                  child: IconButton(
                    padding: EdgeInsets.all(0),
                    icon: Icon(Icons.calendar_today, color: Colors.white,),
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(builder: (context) => HomeScreen(0)));
                      },
                    alignment: Alignment.center,
                  ),
                ),
                Expanded(
                  child: IconButton(
                    padding: EdgeInsets.all(0),
                    icon: Icon(Icons.location_searching,color: Colors.white,),
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(builder: (context) => HomeScreen(1)));
                    },
                    alignment: Alignment.center,
                  ),
                ),

                Expanded(
                  child: IconButton(
                    padding: EdgeInsets.all(0),
                    icon: Icon(Icons.home,color: Colors.white,),
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(builder: (context) => HomeScreen(2)));
                    },
                    alignment: Alignment.center,
                  ),
                ),

                Expanded(
                  child: IconButton(
                    padding: EdgeInsets.all(0),
                    icon: Icon(Icons.notifications,color: Colors.white,),
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(builder: (context) => HomeScreen(3)));
                    },
                    alignment: Alignment.center,
                  ),
                ),
                Expanded(
                  child: IconButton(
                    padding: EdgeInsets.all(0),
                    icon: Icon(Icons.person,color: Colors.white,),
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(builder: (context) => HomeScreen(4)));
                    },
                    alignment: Alignment.center,
                  ),
                ),


              ],
            ),






          // alignment: FractionalOffset.center,

          // color: Colors.pinkAccent,




    )
    );

  }
}
