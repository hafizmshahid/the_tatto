import 'package:flutter/material.dart';

class CustomWidget extends StatefulWidget {
  final String category;
  final int index;
  final bool isSelected;
  final VoidCallback onSelect;

  const CustomWidget({
    this.category,
    Key key,
    @required this.index,
    @required this.isSelected,
    @required this.onSelect,
  })  : assert(index != null),
   assert(category != null),
        assert(isSelected != null),
        assert(onSelect != null),
        super(key: key);

  @override
  _CustomWidgetState createState() => _CustomWidgetState();
}

class _CustomWidgetState extends State<CustomWidget> {

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onSelect,
      child: Container(
        margin: EdgeInsets.all(5.0),

        child: FlatButton(
          onPressed: null,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
              side: BorderSide(color: const Color(0xFFe06287))
          ),


          child: Text(widget.category,style: TextStyle(color:widget.isSelected
          ? Colors.white
              : Colors.grey,fontSize: 14),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,),
          color: Colors.white,




        ),

        decoration: widget.isSelected

        // ?Container()
        // :Container(),








            ? BoxDecoration(color: const Color(0xFFe06287), border:  Border.all(color: const Color(0xFFe06287),),borderRadius:BorderRadius.circular(10),
         )

            : BoxDecoration(),
      ),
    );
  }
}