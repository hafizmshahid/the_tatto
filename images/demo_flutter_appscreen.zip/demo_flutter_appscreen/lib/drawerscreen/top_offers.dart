import 'package:carousel_slider/carousel_slider.dart';
import 'package:demo_flutter_appscreen/appbar/app_bar_only.dart';
import 'package:demo_flutter_appscreen/common/common_view.dart';
import 'package:demo_flutter_appscreen/drawer/drawer_only.dart';
import 'package:demo_flutter_appscreen/model/offerdata.dart';
import 'package:flutter/material.dart';


void main() {
  runApp(new MaterialApp(
    debugShowCheckedModeBanner: false,
    home: new TopOffers(),
  ));
}

class TopOffers extends StatefulWidget {

  @override
  _TopOffers createState() => new _TopOffers();
}


class _TopOffers extends State<TopOffers> {
  CarouselSlider carouselSlider;
  int _current = 1;
  List imgList = [
    'https://images.unsplash.com/photo-1502117859338-fd9daa518a9a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60',
    'https://images.unsplash.com/photo-1554321586-92083ba0a115?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60',
    'https://images.unsplash.com/photo-1536679545597-c2e5e1946495?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60',

  ];

  List offerdatalist = [
    {"discount": "10%", "dark_color":const Color(0xFFffb5cc) , "light_color": const Color(0xFFffc8de),},
    {"discount": "50%", "dark_color": const Color(0xFFb5b8ff), "light_color": const Color(0xFFc8caff)},
    {"discount": "30%", "dark_color": const Color(0xFFffb5b5), "light_color": const Color(0xFFffc8c8)},


  ];

  List<T> map<T>(List list, Function handler) {
    List<T> result = [];
    for (var i = 0; i < list.length; i++) {
      result.add(handler(i, list[i]));
    }
    return result;
  }



  final GlobalKey<ScaffoldState> _drawerscaffoldkey =
  new GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
   return new SafeArea(

      child: Scaffold(

        backgroundColor: Colors.white,
        appBar: appbar(context, 'Top Offers', _drawerscaffoldkey),



     body: Scaffold(
    resizeToAvoidBottomPadding: true,
    key: _drawerscaffoldkey,
    //set gobal key defined above

    drawer: new DrawerOnly(),

        body: new Stack(
          children: <Widget>[
            new SingleChildScrollView(
              child: Column(
              // mainAxisSize: MainAxisSize.min,
              children: <Widget>[



                Container(


                  width: 400,
                  height: 200,
                  alignment: Alignment.topCenter,
                  margin: EdgeInsets.only(top:10,left: 20,right: 20),


                  child: Container(
                    child: Stack(
                      alignment: Alignment.bottomCenter,
                      children: <Widget>[


                        Flexible(
                          child: CarouselSlider(


                            options: CarouselOptions(
                              height: 180,
                              viewportFraction: 1.0,
                              onPageChanged: (index,index1) {
                                setState(() {
                                  _current = index;
                                });
                              },




                            ) ,
                            items: imgList.map((imgUrl) {
                              return Builder(
                                builder: (BuildContext context) {
                                  return Container(

                                      child:Stack(

                                        children: <Widget>[

                                          Material(
                                            color: Colors.white,
                                            borderRadius: BorderRadius.circular(10.0),
                                            elevation: 2.0,
                                            clipBehavior: Clip.antiAliasWithSaveLayer,
                                            type: MaterialType.transparency,
                                            child: Image.network( imgUrl,

                                              height: 200,
                                              width: 500,
                                              fit: BoxFit.fitWidth,
                                            ),


                                          ),

                                          Center(
                                            child: Text('Book The Best Barber.',style: TextStyle(color: Colors.white,fontSize: 26,fontWeight: FontWeight.w800),),

                                          )

                                        ],
                                      )



                                  );
                                },
                              );
                            }).toList(),
                          ),
                        ),
                        Flexible(
                          child:Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: map<Widget>(imgList, (index, url) {
                              return Container(
                                alignment: Alignment.bottomCenter,
                                width: 10.0,
                                height: 10.0,
                                margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 2.0),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _current == index ? Colors.redAccent : Colors.white,
                                ),
                              );
                            }),
                          ),

                        )
                      ],
                    ),
                  ),
                ),




                Container(

                  margin: EdgeInsets.only(top: 5.0,left: 10,right: 10),
                  color: Colors.white,


                  child:Container(
                    child:ListView.builder(

                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),


                      itemBuilder: (BuildContext context, int index) {
                        return new OfferData(
                          discount: offerdatalist[index]['discount'],
                          dark_color: offerdatalist[index]['dark_color'],
                          light_color: offerdatalist[index]['light_color'],
                        );
                      },
                      itemCount: offerdatalist.length,
                    ),



                  ),

                  // height: 50,
                ),
              ],
            ),
          ),

            new Container(child: Body())





        ],

      )



      ),
      ),
    );


  }

}

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Container(

        child: CustomView(),

      ),
    );
  }
}