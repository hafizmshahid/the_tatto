import 'package:flutter/material.dart';

Widget appbar(BuildContext context, String title, dynamic otherData) {
  final GlobalKey<ScaffoldState> _drawerscaffoldkey = otherData;

  return AppBar(


          backgroundColor: Colors.white,
          centerTitle: true,
          elevation: 0.0,
          iconTheme: new IconThemeData(color: Colors.black),
          title: Text(
            title,
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black),
          ),
          leading: IconButton(
            onPressed: () {
              //on drawer menu pressed
              if (_drawerscaffoldkey.currentState.isDrawerOpen) {
                //if drawer is open, then close the drawer
                Navigator.pop(context);
              } else {
                _drawerscaffoldkey.currentState.openDrawer();
                //if drawer is closed then open the drawer.
              }
            },
            icon: Icon(Icons.menu),
          ),
          actions: <Widget>[
            IconButton(
              icon: Icon(
                Icons.search,

                color: Colors.black,
              ),
              onPressed: () {
                // do something
              },
            ),
            IconButton(
              icon: Icon(
                Icons.calendar_today,
                color: Colors.black,
              ),
              onPressed: () {



                // do something
              },
            ),
          ],





  );
}
