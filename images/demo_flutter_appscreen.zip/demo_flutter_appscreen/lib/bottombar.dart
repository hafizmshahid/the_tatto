import 'package:demo_flutter_appscreen/fragments/fghome.dart';
import 'package:demo_flutter_appscreen/fragments/map.dart';
import 'package:demo_flutter_appscreen/fragments/notification.dart';
import 'package:demo_flutter_appscreen/fragments/appoinment.dart';
import 'package:flutter/material.dart';

import 'fragments/profile.dart';

class BottomBar extends StatefulWidget {
  int index ;
  BottomBar(this.index);

  @override
  State<StatefulWidget> createState() {
    return BottomBar1();
  }
}



class BottomBar1 extends State<BottomBar> {
  TabController _controller;






  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new MaterialApp(
      color: Colors.yellow,
      home: DefaultTabController(
        length: 5,
        initialIndex: widget.index,
        child: new Scaffold(
          body: TabBarView(
            children: [
              Appoinment(),
              Map(),
              FgHome(),
              Notification1(),
              Profile(),

            ],
          ),
          bottomNavigationBar: new TabBar(
            tabs: [
              Tab(
                icon: new Icon(Icons.calendar_today),
              ),
              Tab(
                icon: new Icon(Icons.location_searching),
              ),
              Tab(
                icon: new Icon(Icons.home),
              ),
              Tab(icon: new Icon(Icons.notifications),),
              Tab(icon: new Icon(Icons.person),)
            ],
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white,
            indicatorSize: TabBarIndicatorSize.label,
            indicatorPadding: EdgeInsets.all(0.0),
            indicatorColor: Colors.white,
            indicatorWeight: 5.0,
          ),
          backgroundColor: const Color(0xFFe06287),
        ),
      ),
    );
  }
}

